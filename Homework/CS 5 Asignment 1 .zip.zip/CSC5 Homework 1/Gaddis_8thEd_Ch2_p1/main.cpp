/* 
 * File:   main.cpp
 * Author: Tristan Romero 
 * Created on February 19, 2017, 8:00 PM
 * Purpose:  Store the sum of two variables 
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    
    int V1 = 62, // Variable 1
            V2 = 99, //variable 2
            Sum = V1 + V2; 
    
    cout << "the sum of V1 and V2 is" <<Sum<< endl;
    
    //Exit stage right!
    return 0;
}

