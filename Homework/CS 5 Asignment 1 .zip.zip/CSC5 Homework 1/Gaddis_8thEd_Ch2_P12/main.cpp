/* 
 * File:   main.cpp
 * Author: Tristan Romero 
 * Created on February 19, 2017, 6:26 PM
 * Purpose: DIsplay this awesome Diamond       
 *
 *                *
 *               ***
 *              *****
 *             *******
 *              *****
 *               ***
 *                * 
*/

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist


int main(int argc, char** argv) {
   
    cout << "   *" << endl;
    cout << "  ***" << endl;
    cout << " *****" << endl;
    cout << "*******" << endl;
    cout << " *****" << endl;
    cout << "  ***" << endl;
    cout << "   *" << endl;
    
    //Exit stage right!
    return 0;
}

